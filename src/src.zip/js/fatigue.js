const $ = s => document.querySelector(s);
const api = {
  async add({ type, value }) {
    const res = await fetch('/api/fatigue', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type, value })
    });
    if (!res.ok) throw new Error('add failed');
    return res.json();
  }
};
function hint(m){ const el=$('#fgHint'); if(el) el.textContent=m; }
async function onAdd(){
  const type=$('#fgType').value;
  const value=Number($('#fgValue').value);
  if (Number.isNaN(value)) return hint('Enter 0–100');
  try{ await api.add({type,value}); hint('Saved ✓'); $('#fgValue').focus(); }
  catch(e){ console.error(e); hint('Save failed'); }
}
document.addEventListener('DOMContentLoaded', ()=>{
  $('#fgAdd')?.addEventListener('click', onAdd);
  $('#fgRefresh')?.addEventListener('click', ()=>hint('List endpoint not wired yet'));
});
