const $ = s => document.querySelector(s);

const api = {
  async list(date) {
    const res = await fetch(`/api/schedule?date=${encodeURIComponent(date)}`);
    if (!res.ok) throw new Error('list failed');
    const { items } = await res.json();
    return (items || []).sort((a, b) => (a.startAt || '').localeCompare(b.startAt || ''));
  },
  async add({ date, title, startAt, endAt }) {
    const res = await fetch('/api/schedule', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ date, title, startAt, endAt })
    });
    if (!res.ok) throw new Error('add failed');
    return res.json();
  }
};

const pad = n => String(n).padStart(2, '0');
const toISODate = d => d.toISOString().slice(0, 10);
const hhmm = iso => {
  if (!iso) return '--:--';
  const t = new Date(iso);
  return `${pad(t.getHours())}:${pad(t.getMinutes())}`;
};
const tie = (date, hm) => hm ? `${date}T${hm}:00.000Z` : null;

function renderHours(container) {
  container.innerHTML = '';
  container.style.position = 'relative';
  container.style.border = '1px solid #d9d9d9';
  container.style.borderRadius = '10px';
  container.style.background = '#fafafa';
  container.style.height = '840px'; // 24 * 35px
  container.style.overflow = 'hidden';

  const left = document.createElement('div');
  left.style.position = 'absolute';
  left.style.left = 0; left.style.top = 0;
  left.style.width = '48px'; left.style.bottom = 0;
  left.style.background = '#fff';
  left.style.borderRight = '1px solid #ececec';
  container.appendChild(left);

  const track = document.createElement('div');
  track.className = 'tt-track';
  track.style.position = 'absolute';
  track.style.left = '48px';
  track.style.right = '0';
  track.style.top = '0';
  track.style.bottom = '0';
  container.appendChild(track);

  for (let h = 0; h < 24; h++) {
    const row = document.createElement('div');
    row.style.position = 'absolute';
    row.style.left = 0; row.style.right = 0;
    row.style.top = `${h * 35}px`;
    row.style.height = '35px';
    row.style.borderBottom = '1px solid #f1f1f1';
    left.appendChild(row);

    const label = document.createElement('div');
    label.textContent = h;
    label.style.position = 'absolute';
    label.style.left = '6px'; label.style.top = `${h * 35 + 2}px`;
    label.style.fontSize = '12px'; label.style.color = '#666';
    container.appendChild(label);

    const tick = document.createElement('div');
    tick.style.position = 'absolute';
    tick.style.left = '48px'; tick.style.right = '0';
    tick.style.top = `${h * 35}px`;
    tick.style.height = '1px'; tick.style.background = '#f3f3f3';
    container.appendChild(tick);
  }
  return track;
}

function drawItem(track, { title, startAt, endAt }) {
  const pxPerMin = 35 / 60;
  const mins = (iso) => {
    if (!iso) return 0;
    const d = new Date(iso);
    return d.getHours() * 60 + d.getMinutes();
  };
  const start = mins(startAt);
  const end = endAt ? mins(endAt) : start + 60;
  const top = start * pxPerMin;
  const h = Math.max(18, (end - start) * pxPerMin);

  const box = document.createElement('div');
  box.style.position = 'absolute';
  box.style.left = '8px'; box.style.right = '8px';
  box.style.top = `${top}px`; box.style.height = `${h}px`;
  box.style.border = '1px solid #9bbcff';
  box.style.background = '#eef4ff';
  box.style.borderRadius = '10px';
  box.style.padding = '6px 8px';
  box.style.boxShadow = '0 2px 8px rgba(0,0,0,.08)';
  box.style.overflow = 'hidden';

  const h5 = document.createElement('div');
  h5.textContent = title || '(no title)';
  h5.style.fontWeight = '600'; h5.style.fontSize = '13px'; h5.style.marginBottom = '4px';
  const time = document.createElement('div');
  time.textContent = `${hhmm(startAt)} – ${hhmm(endAt)}`;
  time.style.fontSize = '12px'; time.style.color = '#333';

  box.appendChild(h5); box.appendChild(time);
  track.appendChild(box);
}

async function refresh(date) {
  document.getElementById('dayLabel').textContent = date;
  const items = await api.list(date);

  // list
  const ul = document.getElementById('scheduleList');
  if (ul) {
    ul.innerHTML = '';
    items.forEach(it => {
      const li = document.createElement('li');
      li.textContent = `[${hhmm(it.startAt)}–${hhmm(it.endAt)}] ${it.title || '(no title)'}`;
      ul.appendChild(li);
    });
  }

  // timetable
  const container = document.getElementById('timetable');
  if (container) {
    const track = renderHours(container);
    items.forEach(it => drawItem(track, it));
  }
}

async function onAdd() {
  const date = document.getElementById('scheduleDate')?.value;
  const title = document.getElementById('scheduleTitle')?.value?.trim();
  const start = document.getElementById('scheduleStart')?.value;
  const end = document.getElementById('scheduleEnd')?.value;
  if (!date) return toast('Pick a date');
  if (!title) return toast('Enter a title');
  await api.add({ date, title, startAt: tie(date, start), endAt: tie(date, end) });
  toast('Saved ✓');
  document.getElementById('scheduleTitle').value = '';
  await refresh(date);
}

function toast(msg) {
  const el = document.getElementById('scheduleHint');
  if (el) el.textContent = msg;
}

function shift(dateISO, delta) {
  const d = new Date(dateISO + 'T00:00:00');
  d.setDate(d.getDate() + delta);
  return toISODate(d);
}

document.addEventListener('DOMContentLoaded', async () => {
  const input = document.getElementById('scheduleDate');
  if (input && !input.value) input.value = toISODate(new Date());
  document.getElementById('scheduleAdd')?.addEventListener('click', onAdd);
  document.getElementById('scheduleDate')?.addEventListener('change', (e) => refresh(e.target.value));
  document.getElementById('prevDay')?.addEventListener('click', async () => {
    const d = shift(document.getElementById('scheduleDate').value, -1);
    document.getElementById('scheduleDate').value = d; await refresh(d);
  });
  document.getElementById('nextDay')?.addEventListener('click', async () => {
    const d = shift(document.getElementById('scheduleDate').value, +1);
    document.getElementById('scheduleDate').value = d; await refresh(d);
  });
  document.getElementById('todayDay')?.addEventListener('click', async () => {
    const d = toISODate(new Date());
    document.getElementById('scheduleDate').value = d; await refresh(d);
  });
  await refresh(document.getElementById('scheduleDate')?.value || toISODate(new Date()));
});
